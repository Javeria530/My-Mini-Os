import os

# Get the current directory
current_dir = os.getcwd()

# Iterate over all files in the current directory
for filename in os.listdir(current_dir):
    # Get the full path of the file
    file_path = os.path.join(current_dir, filename)
    
    # Check if the file is a regular file
    if os.path.isfile(file_path):
        # Change the permissions of the file to 777 for all users
        os.chmod(file_path, 0o777)

print("Permissions changed successfully!")
